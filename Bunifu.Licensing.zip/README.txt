1. On Visual Studio, right click on solution or project and select Manage NuGet Packages
2. Install Bunifu UI Winform
3. Close Visual Studio
4. Go to [your solution directory]\packages\Bunifu.UI.WinForms.x.x.x\lib and replace Bunifu.Licensing.dll
5. Open your solution, it should be automatically activated

Bunifu.Licensing.dll is based on 4.1.1 but it should work on future versions and should work for Bunifu Datawiz Forms NuGet version

Virus total: https://www.virustotal.com/gui/file/7ff9a81f603a46362227affee1ee9a4cce23dacb1f9478d5b52f3ec08275126d/detection

Do feel free to check what I have changed in .dll file using dnspy, I have nothing to hide, Strings are decrypted using AgileStringDecryptor